import argparse

def get_predict_arguments():
    """
    Retrieves and parses the command line arguments provided by the user when
    they run the program from a terminal window. This function uses Python's 
    argparse module to created and defined these command line arguments. If 
    the user fails to provide some or all of the arguments, then the default 
    values are used for the missing arguments. 
    Command Line Arguments:
      1. Path to Image as path_to_image
      2. Checkpoint Folder as --save_dir with default value 'checkpoint.pth'
      3. top K
      
    This function returns these arguments as an ArgumentParser object.
    Parameters:
     None - simply using argparse module to create & store command line arguments
    Returns:
     parse_args() -data structure that stores the command line arguments object  
    """
    # Create Parse using ArgumentParser
    
    parser = argparse.ArgumentParser()
    
    parser.add_argument("path_to_image")
    parser.add_argument("save_dir", help = 'directory to save checkpoint')
    parser.add_argument('--top_k', type = int, default = 5, help = 'top K classification probability')
    parser.add_argument('--cat_to-names', type = str, help = 'category to names mapping')
    parser.add_argument('--device', type = str, default = 'cpu', help = 'device to use: gpu or cpu')
    
    return parser.parse_args()