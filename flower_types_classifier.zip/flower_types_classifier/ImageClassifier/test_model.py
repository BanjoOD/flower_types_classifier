
def test_model(model, criterion, optimizer, device='cpu'):
    _,_,testloaders = transform_data(input_arguments.data_directory)
    model.eval()
    print('Testing model with test data...')
    test_loss = 0
    accuracy = 0
    test_losses = []
    with torch.no_grad():
        
        for image, label in testloaders:
            image, label = image.to(device), label.to(device)
                
            log_ps = model(image)
            loss_te = criterion(log_ps, label)
            test_loss += loss_te.item()
                
            ps = torch.exp(log_ps)
            top_p, top_class = ps.topk(1, dim=1)
            equality = top_class == label.view(*top_class.shape)
            accuracy += torch.mean(equality.type(torch.FloatTensor))
                
    test_losses.append(test_loss/len(testloaders))
                
    print("Test Loss: {:.3f}".format(test_loss/len(testloaders)), 
          "Test Accuracy: {:.3f}".format(accuracy/len(testloaders)))
    print('model testing done.')

test_model(model, criterion, optimizer, device='cpu')