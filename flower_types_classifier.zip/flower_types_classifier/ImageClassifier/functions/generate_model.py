#import classifier network
from torchvision import models
from Network import network

def generate_model(arch, hidden_units):
     
    if arch == 'densenet' or arch =='vgg':
        if arch = 'densenet':
            model = models.densenet121(pretrained=True)
        else:
            model = models.vgg16(pretrained=True)
        #Freeze features parameters
        for param in model.parameters():
            param.requires_grad = False
        model.classifier = network(hidden_units)
        
    elif arch == 'resnet':
        model = models.resnet18(pretrained=True)
        #Freeze features parameters
        for param in model.parameters():
            param.requires_grad = False
        model.fc = network(hidden_units)
        
    else:
        
        #Freeze features parameters
        for param in model.parameters():
            param.requires_grad = False
        model.fc = network(hidden_units)
        
        return model