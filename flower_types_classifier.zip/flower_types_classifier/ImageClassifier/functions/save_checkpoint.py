
def save_checkpoint(model, checkpoint_path, hidden_units, arch, optimizer):
    print('saving checkpoint in {}...'.format(checkpoint_path)
    checkpoint  = {'input_size': hidden_units,
                   'output_size': 102,
                   'optmizer_state': optimizer.state_dict(),
                   'epochs': epochs,
                   'train_losses': train_losses,
                   'arch': arch,
                   'cat_to_name': model.cat_to_name,
                   'idx_to_class': model.idx_to_class,
                   'state_dict': model.state_dict()}
    if arch == 'densenet':
        checkpoint['classifier'] = model.classifier
    elif arch == 'resnet': 
        checkpoint['classifier'] = model.fc
    else:
        checkpoint['classifier'] = model.fc
        
    torch.save(checkpoint, checkpoint_path)
    
    print('checkpoint saved.')