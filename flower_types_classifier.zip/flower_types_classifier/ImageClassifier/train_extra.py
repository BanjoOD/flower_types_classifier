# Imports here
import time
import copy
import torch
from torch import nn, optim
from torchvision import datasets, transforms, models
import torch.nn.functional as F

from  get_inputs_arguments import get_input_arguments
from transform_data import transform_data
#import classifier network
from Network import network

input_arguments = get_input_arguments()
def generate_model(arch, hidden_units):
     
    if arch == 'densenet' or arch =='vgg':
        if arch == 'densenet':
            model = models.densenet121(pretrained=True)
        else:
            model = models.vgg16(pretrained=True)
        #Freeze features parameters
        for param in model.parameters():
            param.requires_grad = False
        model.classifier = network(hidden_units)
        
    elif arch == 'resnet':
        model = models.resnet18(pretrained=True)
        #Freeze features parameters
        for param in model.parameters():
            param.requires_grad = False
        model.fc = network(hidden_units)
               
    return model

#Train model function
def train_model(model, criterion, optimizer, epochs=25, device = 'cpu'):
    model.to(device)
    #Training...
    print('Training model with training and validation data now...')
    trainloaders, validloaders,_,_ = transform_data(input_arguments.data_directory)
    steps = 0
    print_every = 50
    running_loss = 0
    train_losses, valid_losses = [], []
    for e in range(epochs):
        for images, labels in trainloaders:
            steps += 1
            #images & labels to device
            images, labels = images.to(device), labels.to(device)
        
            #start training loop
            optimizer.zero_grad()
            logits = model(images)
            loss_tr = criterion(logits, labels)
            loss_tr.backward()
            optimizer.step()
        
            running_loss += loss_tr.item()      
      
        
            if steps % print_every == 0:
                model.eval()
                valid_loss = 0
                accuracy = 0
                with torch.no_grad():
                    for image, label in validloaders:
                        image, label = image.to(device), label.to(device)
                
                        log_ps = model(image)
                        loss_va = criterion(log_ps, label)
                        valid_loss += loss_va.item()
                
                        ps = torch.exp(log_ps)
                        top_p, top_class = ps.topk(1, dim=1)
                        equality = top_class == label.view(*top_class.shape)
                        accuracy += torch.mean(equality.type(torch.FloatTensor))
                
                train_losses.append(running_loss/len(trainloaders))
                valid_losses.append(valid_loss/len(validloaders))
                
                print("Epoch: {}/{}..".format(e+1, epochs),
                      "Training Loss: {:.3f}".format(running_loss/len(trainloaders)),
                      "Validation Loss: {:.3f}".format(valid_loss/len(validloaders)),
                      "Training Accuracy: {:.3f}".format(accuracy/len(validloaders)))
            
                running_loss = 0
                model.train()
    print('model training done.')
    
    return model

#Test model Function
def test_model(model, criterion, optimizer, device='cpu'):
    _,_,_,testloaders = transform_data(input_arguments.data_directory)
    model.eval()
    print('Testing model with test data...')
    test_loss = 0
    accuracy = 0
    test_losses = []
    with torch.no_grad():
        
        for image, label in testloaders:
            image, label = image.to(device), label.to(device)
                
            log_ps = model(image)
            loss_te = criterion(log_ps, label)
            test_loss += loss_te.item()
                
            ps = torch.exp(log_ps)
            top_p, top_class = ps.topk(1, dim=1)
            equality = top_class == label.view(*top_class.shape)
            accuracy += torch.mean(equality.type(torch.FloatTensor))
                
    test_losses.append(test_loss/len(testloaders))
                
    print("Test Loss: {:.3f}".format(test_loss/len(testloaders)), 
          "Test Accuracy: {:.3f}".format(accuracy/len(testloaders)))
    print('model testing done.')
  
#Save Checkpoiint Function
def save_checkpoint(model, checkpoint_path, arch, optimizer, hidden_units):
    print('saving checkpoint in {}...'.format(checkpoint_path))
    checkpoint  = {'input_size': hidden_units,
                   'output_size': 102,
                   'optmizer_state': optimizer.state_dict(),
                   'arch': arch,
                   'cat_to_name': model.cat_to_name,
                   'idx_to_class': model.idx_to_class,
                   'state_dict': model.state_dict()}
    if arch == 'densenet' or arch == 'vgg':
        checkpoint['classifier'] = model.classifier
    
    else:
        checkpoint['classifier'] = model.fc
        
    torch.save(checkpoint, checkpoint_path)
    
    print('checkpoint saved.')
          
          