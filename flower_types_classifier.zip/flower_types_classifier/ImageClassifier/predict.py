
from get_predicts_arguments import get_predict_arguments
import predict_extra

pred_arguments = get_predict_arguments()
data_iter = pred_arguments.path_to_image #test_dir + '/1/image_06743.jpg'

probs, classes = predict_extra.predict(data_iter, pred_arguments.save_dir, pred_arguments.top_k)
print("flower name: {}".format(classes))
print("probability: {}".format(probs))

#extra_predict.plot_results(data_iter, probs, classes, pred_arguments.top_k)