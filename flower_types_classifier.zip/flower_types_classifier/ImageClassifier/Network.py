from torch import nn
import torch.nn.functional as F

class network(nn.Module):
    def __init__(self, hidden_units):
        super().__init__()
        self.hidden1 = nn.Linear(hidden_units, 500)
        self.hidden2 = nn.Linear(500, 256)
        self.hidden3 = nn.Linear(256, 102)
       
        
        self.dropout = nn.Dropout(p = 0.2)
        
    def forward(self, x):
        #flatten...
        x = x.view(x.shape[0], -1)
        
        x = self.dropout(F.relu(self.hidden1(x)))
        x = self.dropout(F.relu(self.hidden2(x)))
        
        
        x = F.log_softmax(self.hidden3(x), dim=1)
        
        return x