import argparse

def get_input_arguments():
    """
    Retrieves and parses the command line arguments provided by the user when
    they run the program from a terminal window. This function uses Python's 
    argparse module to created and defined these command line arguments. If 
    the user fails to provide some or all of the arguments, then the default 
    values are used for the missing arguments. 
    Command Line Arguments:
      1. Checkpoint Folder as --save_dir with default value 'workspace'
      2. Pretrained Model Architecture as --arch with default value 'densenet121'
      3. Learning rate  as --learning_rate with default value 0.001
      4. Epochs as --epochs with default value 5
      5. Device to train on as --device with default as 'cuda'
      6. Hidden units as --hidden_units with default as 1024
      
    This function returns these arguments as an ArgumentParser object.
    Parameters:
     None - simply using argparse module to create & store command line arguments
    Returns:
     parse_args() -data structure that stores the command line arguments object  
    """
    # Create Parse using ArgumentParser
    
    parser = argparse.ArgumentParser()
    
    parser.add_argument("data_directory")
    parser.add_argument('--save_dir', type = str, default = 'checkpoint.pth', help = 'directory to save checkpoint')
    parser.add_argument('--arch', type = str, default = 'densenet', choices = ['densenet', 'resnet', 'vgg'], help = 'Pretrained Network model to be used')
    parser.add_argument('--lr', type = float, default = 0.001, help = 'learning rate')
    parser.add_argument('--epochs', type = int, default = 5, help = 'Epoch')
    parser.add_argument('--device', type = str, default = 'cpu', help = 'device to train with: cuda or cpu')
    parser.add_argument('--hidden_units', type = int, default = 1024, help = 'hidden units to  be used in the classifier training')
    parser.add_argument('--top_k', type = int, default = 5, help = 'top K classification probability')
    parser.add_argument('--cat_to-names', type = str, help = 'category to names mapping')
    
    return parser.parse_args()