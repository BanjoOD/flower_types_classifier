import torch
from torch import nn, optim
from torchvision import datasets, transforms, models

from PIL import Image
import numpy as np
import json

from  get_inputs_arguments import get_input_arguments
from transform_data import transform_data
from workspace_utils import active_session
import train_extra

def main():
    input_arguments = get_input_arguments()
    
    with open('cat_to_name.json', 'r') as f:
        cat_to_name = json.load(f)
    
    # TODO: Build and train your network
    if input_arguments.device == 'gpu' and torch.cuda.is_available():
        device = torch.device('cuda') 
    else:
        device = torch.device('cpu')
        
    model = train_extra.generate_model(input_arguments.arch, input_arguments.hidden_units)
                 
    criterion = nn.NLLLoss()
    optimizer = optim.Adam(model.classifier.parameters(), lr = input_arguments.lr)
    
    model = train_extra.train_model(model, criterion, optimizer, input_arguments.epochs, device)
    
    train_extra.test_model(model, criterion, optimizer, device)
                  
    # TODO: Save the checkpoint 
    _,_,train_datasets,_ = transform_data(input_arguments.data_directory)
    model.idx_to_class = dict((v,k) for k,v in train_datasets.class_to_idx.items())
    model.cat_to_name = cat_to_name
   
    train_extra.save_checkpoint(model, input_arguments.save_dir, input_arguments.arch, optimizer, input_arguments.hidden_units)

with active_session(180):
    if __name__ == "__main__":
        main()
            

