# Imports here
import torch
from torch import nn, optim
from torchvision import datasets, transforms, models
import torch.nn.functional as F
from PIL import Image
import numpy as np
import json

#matplotlib inline
#config InlineBackend.figure_format = 'retina'

import matplotlib.pyplot as plt

def load_network(filepath, category_names = ""):
    checkpoint = torch.load(filepath, map_location = lambda storage, loc: storage)
    if checkpoint['arch'] == 'densenet':
        model = models.densenet121(pretrained = True)
        model.classifier = checkpoint['classifier']
    elif checkpoint['arch'] == 'resnet':
        model = models.resnet18(pretrained = True)
        model.fc = checkpoint['classifier']
    else:
        model = models.vgg16(pretrained=True)
        model.fc = checkpoint['classifier']
    
    if category_names != "":
        model.cat_to_name = category_names
    else:
        model.cat_to_name = checkpoint['cat_to_name']
        
    model.idx_to_class = checkpoint['idx_to_class']
    model.load_state_dict(checkpoint['state_dict'])
    #optimizer.load_state_dict(checkpoint['optimizer'])
    
    return model

def process_image(image):
    ''' Scales, crops, and normalizes a PIL image for a PyTorch model,
        returns an Numpy array
    '''
    # TODO: Process a PIL image for use in a PyTorch model
    pil_image = Image.open(image)
    
    image_transform = transforms.Compose([transforms.Resize(255),
                                          transforms.CenterCrop(224),
                                          transforms.ToTensor(),
                                          transforms.Normalize([0.485, 0.456, 0.406],
                                                               [0.229, 0.224, 0.225])])
    #pil_transform = Image.resize(255)
    image_data = image_transform(pil_image) #datasets.ImageFolder(pt_image, transform = image_transform)
    
    #pt_image = np.array(image_data).transpose()
    # pt_image = np_image.ndarray.transpose()
   
    
    #imageloader = torchvision.utils.data.DataLoader(image_data)
    return image_data

def imshow(image, ax=None, title=None):
    """Imshow for Tensor."""
    if ax is None:
        fig, ax = plt.subplots()
    
    # PyTorch tensors assume the color channel is the first dimension
    # but matplotlib assumes is the third dimension
    image = image.numpy().transpose((1, 2, 0))
    
    # Undo preprocessing
    mean = np.array([0.485, 0.456, 0.406])
    std = np.array([0.229, 0.224, 0.225])
    image = std * image + mean
    
    # Image needs to be clipped between 0 and 1 or it looks like noise when displayed
    image = np.clip(image, 0, 1)
    
    ax.imshow(image)
    ax.set_title(title)
    
    return ax

def predict(image_path, model_checkpoint, topk=5):
    ''' Predict the class (or classes) of an image using a trained deep learning model.
    '''
    # TODO: Implement the code to predict the class from an image file
    model = load_network(model_checkpoint)
    model.eval()
    image = process_image(image_path)
    
    image = image.unsqueeze_(0)
    
    pred  = torch.exp(model(image))
    
    top_pred, top_class = pred.topk(topk, dim=1)
    
    top_pred = top_pred.data.numpy().squeeze().tolist()
  
    top_flowers = [model.cat_to_name[model.idx_to_class[lab]] for lab in top_class.data.numpy().squeeze().tolist()]
   # top_flowers = [model.cat_to_name[i] for i in [str(j) for j in top_class.numpy().squeeze().tolist()[0]]
    
    return top_pred, top_flowers


def plot_results(data_iter, probs, classes, topk):
    ''' Plots the top K classes) to predict the image passed through it.
    '''
    # TODO: Display an image along with the top K classes
    
    fig, (ax1, ax2) =  plt.subplots(figsize = (6,9), nrows=2)

    imshow(process_image(data_iter), ax = ax1, title = classes[0])
    ax1.axis('off')
    
    ax2.barh(np.arange(topk, topk - topk,-1), probs)
    ax2.set_aspect(0.1)
    ax2.set_yticks(np.arange(topk, topk - topk,-1))
    ax2.set_yticklabels(classes)

    ax2.set_title('Class Probability')
    ax2.set_xlim(0, 1.1)

    plt.tight_layout()
    plt.show()